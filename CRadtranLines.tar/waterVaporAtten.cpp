/***********************************************************************
 * waterVaporAtten.cpp:
 *    Source code for waterVaporAtten class
 * Author:
 *    Alexander Marvin
 * Summary:
 *    Calculates the attenuation from water vapor.
 ***********************************************************************/

#include "atten.h"
#include <iostream>

